import path from "path";
import { fileURLToPath } from "url";
import express from "express";
import rateLimit from "express-rate-limit";
import { visit } from "./bot.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = 1337;
const app = express();
app.use(express.json());

app.use(express.static(path.join(__dirname, "public")));

app.use("/api", rateLimit({ windowMs: 90_000, max: 3 }));
app.use((req, res, next) => {
  // Prevent Attack
  res.header(
    "Content-Security-Policy",
    "default-src 'none'; style-src 'sha256-eGLZdM7pIzHSBTFrEV33rSazkvKhzU2r0KPv3HEJ86k=' 'self'; script-src 'self'; img-src http:; connect-src 'none'; frame-src 'none'; frame-ancestors 'none';"
  );
  res.setHeader("Referrer-Policy", "no-referrer");
  res.setHeader("Cache-Control", "no-store");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("X-Content-Type-Options", "nosniff");
  next();
});

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.post("/api/report", async (req, res) => {
  const { url } = req.body;
  if (
    typeof url !== "string" ||
    (!url.startsWith("http://") && !url.startsWith("https://"))
  ) {
    return res.status(400).send("Invalid url");
  }
  try {
    await visit(url);
    return res.sendStatus(200);
  } catch (e) {
    console.error(e);
    return res.status(500).send("Something wrong");
  }
});

app.listen(PORT);
