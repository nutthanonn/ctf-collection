import puppeteer from "puppeteer";

const FLAG = process.env.GZCTF_FLAG || "STDIO2025_06{0182734aebcd}";
const APP_HOST = "127.0.0.1";
const APP_PORT = "1337";
export const APP_URL = `http://${APP_HOST}:${APP_PORT}`;

console.log("[bot]: flag set to", FLAG);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export const visit = async (url) => {
  console.log(`start: ${url}`);

  const browser = await puppeteer.launch({
    headless: "new",
    executablePath:
      process.env.PUPPETEER_EXECUTABLE_PATH || puppeteer.executablePath(),
    pipe: true,
    args: [
      "--no-sandbox",
      "--disable-setuid-sandbox",
      "--disable-dev-shm-usage",
      "--no-first-run",
      "--no-default-browser-check",
      "--disable-popup-blocking",
      "--disable-renderer-backgrounding",
      "--disable-background-timer-throttling",
      "--disable-gpu",
      "--disable-software-rasterizer",
      "--disable-extensions",
      "--disable-notifications",
      "--disable-background-networking",
      "--disable-sync",
      "--metrics-recording-only",
      "--mute-audio",
      "--no-default-browser-check",
      "--disable-breakpad",
      "--disable-hang-monitor",
    ],
    defaultViewport: { width: 800, height: 600, deviceScaleFactor: 1 },
  });

  const context = await browser.createBrowserContext();

  try {
    const page = await context.newPage();

    page.on("error", (err) => console.error("Page crashed:", err));
    page.on("pageerror", (err) => console.error("PageError:", err));

    await page.setCookie({
      name: "FLAG",
      value: FLAG,
      url: APP_URL,
      path: "/",
      sameSite: "Lax",
      httpOnly: false,
    });

    await page.goto(url, {
      waitUntil: "domcontentloaded",
      timeout: 30_000,
    });

    await sleep(90_000);
    await page.close({ runBeforeUnload: true });
  } catch (e) {
    console.error("visit() error:", e);
  } finally {
    try {
      await context.close();
    } catch {}
    try {
      if (browser?.isConnected()) await browser.close();
    } catch {}
  }

  console.log(`end: ${url}`);
};
