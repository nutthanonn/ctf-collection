(() => {
  function scrollToShareMark() {
    const el = document.querySelector("mark#share");
    if (!el) return;

    const details = el.closest("details:not([open])");
    if (details) details.open = true;

    const reduce =
      !!window.matchMedia &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const forceAuto = navigator.webdriver === true;
    const behavior = reduce || forceAuto ? "auto" : "smooth";

    el.scrollIntoView({ behavior, block: "center", inline: "nearest" });
    requestAnimationFrame(() => {
      el.scrollIntoView({
        behavior: "auto",
        block: "center",
        inline: "nearest",
      });
    });
  }

  const run = () => setTimeout(scrollToShareMark, 0);
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", run, { once: true });
  } else {
    run();
  }

  const mo = new MutationObserver(() => {
    if (document.querySelector("mark#share")) {
      requestAnimationFrame(scrollToShareMark);
      mo.disconnect();
    }
  });
  mo.observe(document.documentElement, { childList: true, subtree: true });
})();
