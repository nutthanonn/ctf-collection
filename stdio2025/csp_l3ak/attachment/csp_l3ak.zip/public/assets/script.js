const purifier = window.DOMPurify;

const $ = (id) => document.getElementById(id);

function getCookie(name) {
  const m = document.cookie
    .split(";")
    .map((v) => v.trim())
    .find((v) => v.startsWith(name + "="));
  return m ? decodeURIComponent(m.slice(name.length + 1)) : null;
}

function getParam(name) {
  const v = new URL(location.href).searchParams.get(name);
  return v === null ? null : v;
}

function clamp(n, min, max) {
  const x = Number.isFinite(+n) ? +n : 0;
  return x < min ? min : x > max ? max : x;
}

function setMarkContent(html) {
  const share = String(getParam("share") ?? "").trim();
  if (!share || share === "true") return String(html ?? "");

  const text = String(html ?? "");
  const idx = text.indexOf(share);
  if (idx === -1) return text;

  const frag = document.createDocumentFragment();
  if (idx > 0) frag.append(document.createTextNode(text.slice(0, idx)));

  const mark = document.createElement("mark");
  mark.id = "share";
  mark.textContent = share;
  frag.append(mark);

  const rest = text.slice(idx + share.length);
  if (rest) frag.append(document.createTextNode(rest));

  return frag;
}

function setOutputDangerously(el, html) {
  const nav = performance.getEntriesByType("navigation")[0];
  const allowInnerHTML =
    window.top === window.self &&
    window.opener === null &&
    window.history.length === 1 &&
    nav &&
    nav.type === "navigate" &&
    nav.redirectCount === 0;

  if (allowInnerHTML) {
    const share = String(getParam("share") ?? "").trim();
    if (share) html = html.replace(share, `<mark id="share">${share}</mark>`);
    el.innerHTML = purifier.sanitize(html, { FORBID_TAGS: ["style"] });

    // Close the window
    setTimeout(() => {
      window.close();
    }, 2000);
  } else {
    const content = setMarkContent(html);
    if (content instanceof Node) el.replaceChildren(content);
    else el.textContent = String(content ?? "");
  }
}

function compute() {
  const cookieFlag = getCookie("FLAG");
  const qWord = getParam("word");
  const qCut = getParam("cut");
  const word =
    cookieFlag !== null ? (qWord ?? "") + " " + cookieFlag : (qWord ?? "");
  const cut = clamp(
    qCut === null ? (word ? word.length : 0) : parseInt(qCut, 10),
    0,
    word.length,
  );
  const sliced = (word || "").slice(0, cut);
  setOutputDangerously($("out"), sliced);
  $("wordInput").value = qWord ?? "";
  $("cutInput").value = qCut ?? "";
}

function updateFromInputs() {
  const w = $("wordInput").value;
  const c = $("cutInput").value;
  const u = new URL(location.href);
  if (w) u.searchParams.set("word", w);
  else u.searchParams.delete("word");
  if (c) u.searchParams.set("cut", c);
  else u.searchParams.delete("cut");
  history.replaceState(null, "", u.toString());
  compute();
}

$("goBtn").addEventListener("click", updateFromInputs);

const onEnter = (e) => {
  if (e.key === "Enter") updateFromInputs();
};

$("wordInput").addEventListener("keydown", onEnter);
$("cutInput").addEventListener("keydown", onEnter);

$("shareBtn").addEventListener("click", () => {
  const url = new URL(location.href);
  const share = $("out")?.textContent ?? "";
  url.searchParams.set("share", share || "true");
  navigator.clipboard.writeText(url.toString());
});

compute();
