#!/bin/bash

docker build --platform linux/amd64 -t csp_l3ak .

docker run -d --rm -p 1337:1337 \
  --shm-size=256m \
  --name csp_l3ak \
  csp_l3ak
